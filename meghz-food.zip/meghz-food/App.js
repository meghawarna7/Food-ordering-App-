
import React, {useState} from 'react';
import { 
  Text,
  View,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  ImageBackground,
  ScrollView,
  Alert,
  StatusBar,
  FlatList,
  Image,
  Button,
} from 'react-native';
import { AntDesign } from '@expo/vector-icons';
import { Ionicons } from '@expo/vector-icons';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import {
  createDrawerNavigator,
  DrawerContentScrollView,
  DrawerItemList,
  DrawerItem,
} from '@react-navigation/drawer';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';



// Login Screen Function

function LoginScreen({navigation}){
  const [username, setUname] = useState('');
  const [password, setPword] = useState('');
  return(

      <View style={styles.containerl}>
      <ImageBackground
        style={styles.background}
        source={{ uri: 'https://images.pexels.com/photos/793765/pexels-photo-793765.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1' }}
      >
      
     
        <TextInput
        placeholder="User name" 
        placeholderTextColor="rgba(255,255,255,0.8)" 
        onChangeText={(username) => setUname(username)}
        defaultValue={username}
        returnKeyType="next" 
        style={styles.inputTextl}></TextInput>

        <TextInput 
        placeholder="Password"
        placeholderTextColor="rgba(255,255,255,0.8)" 
        onChangeText={(password) => setPword(password)}
        defaultValue={password}
        returnKeyType="go" 
        secureTextEntry
        style={styles.inputTextl}></TextInput>

        <TouchableOpacity 
        style={styles.buttonContainerl}
        onPress={ () => {
          
          Alert.alert("Login Success");
          navigation.navigate('Home',{itemId: username });
       
        
      }}>
        <Text style={styles.buttonTextl}>Log In</Text>
      </TouchableOpacity>

      <TouchableOpacity 
        style={styles.buttonContainerl}
        onPress={ () => {
         navigation.navigate('Register');
      }}>
        <Text style={styles.buttonTextl}>Register</Text>
      </TouchableOpacity>
 </ImageBackground>
      </View>
  );
}


//Register Screen Function

function RegisterScreen({navigation}){
  const [nusername, setnUname] = useState('');
  const [npassword, setnPword] = useState('');
  const [nepassword, setnePword] = useState('');
  return(

      <View style={styles.containerR}>
       <ImageBackground
        style={styles.background}
        source={{ uri: 'https://images.pexels.com/photos/2092906/pexels-photo-2092906.jpeg?auto=compress&cs=tinysrgb&w=600' }}
      >
        <TextInput
        placeholder="User name" 
        placeholderTextColor="rgba(255,255,255,0.8)" 
        onChangeText={(nusername) => setnUname(nusername)}
        defaultValue={nusername}
        returnKeyType="next" 
        style={styles.inputTextl}></TextInput>

        <TextInput 
        placeholder="Password"
        placeholderTextColor="rgba(255,255,255,0.8)" 
        onChangeText={(npassword) => setnPword(npassword)}
        defaultValue={npassword}
        returnKeyType="go" 
        secureTextEntry
        style={styles.inputTextl}></TextInput>

        <TextInput 
        placeholder="Confirm Password"
        placeholderTextColor="rgba(255,255,255,0.8)" 
        onChangeText={(nepassword) => setnePword(nepassword)}
        defaultValue={nepassword}
        returnKeyType="go" 
        secureTextEntry
        style={styles.inputTextl}></TextInput>

        <TouchableOpacity 
        style={styles.buttonContainerl}
        onPress={ () => {
          var nuname=nusername;
          var npwd=npassword;
          var npwd1=nepassword;
        
        if (nuname=="" || npwd=="" || npwd1==""){
           Alert.alert("Please Fill All The Fields ");
        }else if (npwd == npwd1) {
          Alert.alert("Registration Success");
          navigation.navigate('Login');
        }else{
          Alert.alert("Password Mismatch,Please ReType!");
        }
      }}>
        <Text style={styles.buttonTextl}>Register</Text>
      </TouchableOpacity>
 </ImageBackground>
      </View>
  );
}


// Home Tab screen function

function HomeStackScreen({ navigation,route }){
  const { itemId2 } = route.params;
  return (
    <View style={styles.container1}>
     
     
    
        <Image source={require('./assets/oWYktFSA.gif')} style={styles.logo} />
         <Image source={require('./assets/up.png')} style={styles.w} />
         <Text style={styles.wText}>Enjoy Your Food</Text>
        
      </View>
   
   
  );
}


//Vehicle Tab screen function

function ProductScreen(){
 const [products, setProducts] = useState([
    { id: 1, name: 'Strawberry chunks', price: 49000, image: require('./assets/1.jpg') },
    { id: 2, name: 'choco mix', price: 20, image: require('./assets/2.jpg') },
    { id: 3, name: 'vani Jugs', price: 30, image: require('./assets/3.jpg') },
    { id: 4, name: 'choco favor', price: 40, image: require('./assets/4.jpg') },
    { id: 5, name: 'chees mix', price: 50, image: require('./assets/5.jpg') },
      { id: 5, name: 'hony mix', price: 50, image: require('./assets/6.jpg') },
  ]);

  return (
    <View style={styles.containers}>
      
      <ScrollView>
        {products.map((product) => (
          <View style={styles.productContainer} key={product.id}>
            <Image source={product.image} style={styles.productImage} />
            <Text style={styles.productName}>{product.name}</Text>
            <Text style={styles.productPrice}>${product.price}</Text>
          </View>
        ))}
      </ScrollView>
    </View>
  );

}

function ProfileScreen(){
   
  return (
    <View style={styles.containers}>
      <Image source={{ uri:'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoHCBISEhISEhIPEhIPEhUPDw8PDx8SEhAMJSEnJyUhJCQpLjwzKSw4LSQkNEM0ODs1TTdOKDE8SkhLPzw+NzEBDAwMEA8QGBISGDEdGh0xMT8/MTExPzgxMT80MTU/PzExPzExQDRAPzQ/PDo0OjQ/MT80Pz8xPzExNDExPzExMf/AABEIAMgAyAMBIgACEQEDEQH/xAAcAAABBQEBAQAAAAAAAAAAAAAFAAIDBAYHAQj/xAA8EAACAQIFAQUGAgoCAgMAAAABAgADEQQFEiExQQYTIlFhIzJScYGRQrEHFDNicqHB0eHwgvFDkiQ0g//EABoBAAIDAQEAAAAAAAAAAAAAAAIDAAEEBQb/xAAlEQADAAIDAAIDAAIDAAAAAAAAAQIDERIhMQRBEyJRYXEUMlL/2gAMAwEAAhEDEQA/ANnaex9UbxgmdBMREQE9MaJZQ8CegRoMfeQgrRWivPZZBRT2eMwG5sB5mQh7FaD6ud4VDZ8RQUjoag5gzEdtsChsKj1LHTenTLLq+cshpIpicz/SLhqajuqdSqeur2ar9YJT9KZvvhlt1tV3H8pei9HTJ7aZHLO21CtbxKpb8Jvt89pp6GKVxcEbyitE8UQjpChs8IjrTy0hDwrPLR1p5IQbaKOnhEhDyKIxSEPKvMYI+rzGiCExR2meCew5QLFpi0z2e3l6K2M0mKPuZ5K0TYH7R52mDoNUYjWfDSQ/jqf2nKs07V4jE/tXOkcJTUin9fM/eLtxj3xOMqAs2igzU6Sg7BQbE/U3N5nqKBT+IsTwOgl6QSLDVmH4eRsSbG32jHxNtr6jbexNryV6+wuATawLeH+u8hq4s+Y+nF5AiriatzbpzYecgvJHe+8YYSBJ8M5F7Q5k/aCtRZSKjWHKsbqVmepva/r+c9pk3EpyWmd47LZ4cQtnGl9OsAG4K3tNEDOafo2q3qMDc93TK+m5B/O/2nSlYGLRVej4oopZQ0zyezyQgjPJ7PDIQ8MU8MUhD2tzGR9bmRwQhwkgkYkghoChRRRCWQUTGwJ8hf6RStmT6KNVr2003a/0MhEcOx1nqVKm93dn2FwCSTKBJFySBqO5tuRLz0tTKSQAdgpNmHrB+JJNQ24B2BNtvOAnsc50Nd7bg7+ZXkSodTHj7S2MMXPnNPkWQA2eoCB+EHa8q8qlDMeCrZl8PldR+FO8uP2fqCxsbEeU6HQwCKLBQP7yc01taw22mV/Jpvo2L4kJdnMzkb26/aVamXup+W86PXoADgf2gutQW+4H+Jc/Jr7Av4s66B3YfNO6xADagKngYdNzsfpOxYOpfacPzLBinVBW4V1JsPinVuz2aU2w9Ko7WZqa6r/F1mpUqSZgqXLaZpIrwY+e0F5cfeVanabDj8a/eFoWHbxXmZfthhhy6/ee0u2GFY27xP8A2k0yGlnhMGUc7oPxUXf1l5agIuNwZCxzRRjPFKISVuZHePr8xkEIbVqBVLHgQDW7V0EJBdbjb3usK5qfZP8AKcBzIe2qfxtDlbBZ3/K8xFdNaG4PUeUIpfrMp2A/+qn8ImrvLKHzOdvMU1PA1dOxfTTJ8lJ3/leaG8B9sMD+sYSpSBsWsVv8QkfhJ9OOUMWDcKd+fGORI8Ng3q1AqgkseB5z3BYE94Q+2j3gPiHSdCyTALSpd7oHeOtwAOF6CJulPhsxzyfZVyrI6WHUGppNRhqIPQQuHo8a0vbgMDAuNy2owapiayU9e4TyH3gFWwyONNYsVO7Kht94hyq7b2aptz0lpG7FMH3GB2vPKeGcwdk43Uo+odN+kKY/F92tzttzaJaRoVPXZTxbU6YOth4eQN95msVmFG5IcE+QPSUM3x4dmsxBY9NzaUMLhcO/7SqQ3lsfyjoxLW2Zcmat6QSxwWrTV1IZQ1iRzOsdmuztCpg6BtfVTVv+RE5XQy7u0qFGLUyoY79QRvO1dikK4DDBue7vv5XM0YteIxZd72/QXW7FYa5YqPOci7cYGnQxOinsLXIE+iMSPCflPn39Id/1w/KM1pmf7Miyzy0e0aRDLLOAqOKlMBmF3Xhjxed6ygexS++04Jl49rTH76/nO+5UPZJ8oLLLRAijXMUrRB9fmRySud5GIBZVzX9k/wApwXMB7Wp/G35zvOafsn+U4RmA9rU/jaHJTOu9hqmnBqebIJDX7ZaKoplHF20A6esn7BC+FQHqohqvk9J2DFRcG/HWWUXsLW1oG8xIM0Pg+ss0UCgAbAQf2gxHd0WqaS2kiyg2LN0EqnpbZcS6pSvWcioEGqx6MbX9bzp9NAKY9FFvnMricgCmjVQFFqOgamSDpBPQ9ZsKdPUNvp8pkyUq8OnixuG0zOVckdjUqVh3xqIwpqfdpOeDY7GBsDljUu+76nTqNWVVUKBTVAOtgOZuauoC21v5yBMMGN2H3EWsjS0hzxS3yYIyHLShDAWHN7k7yXtMmpDcn5w2SNlXpzaD84w/szcGx8/KA9jEl4YTJaAp1GLojsQyqHHQ9R6/lIqeVOjsz0xVDIUTUbaB0P0tCVKgO8KMDpPunyaEjgyByxHzjPzUuhP4FXYHymjUprUpPuKiMq3+IztvZof/AA8Ltb2Cbf8AETk7UgvmTfrNV2Gz6tUxDYV21U6dM6AVA0KLWG3oY3Bk/bv7MmfFrz6N5iCQp+U+ff0gvfGNfoJ9BYo2Rj6T537dPfGP6CaX/wBjD9maMZJGMbLLLWVLevSH74ne8vHs0+U4Rki3xFIfvid6wQ9mvykZCHMaTuhCGx6H1ilsiKUQVc7yOOrneNEAJlXM/wBm/wApxLHYVzVqWUnxngTvlCgKh0twZcTs1hhv3a7+nWHKZRj+wyFcMgIIIUbGaeWK+Cp0hZAAPSV4YLPRBPaZSaBt+F0YjzXUIVkWLoipTqKfxKR9Yu1uWhmGuNy/4zCZ7mGk01W2mk66j5sJossxSuim99Q/nMx2kwYWh3gBV2YFwG2MoZBnXdgITwOsxqXo6lWuX+zoTBZQrVfEFHX8pSfMfDe66be8Jicz7X1FdhSC2Xw6285Uw6ekFWWZXZs8zzWphwoSmpvuaruEUQDmna26e6xPoQVmQzHMq2IK95UZgCLIPdEsYfD0xTIOtmblQ235R34kktiPzOm+JawObvVuLKCGDagd5tMLWV1B62sflOTV6ZRifEu/PG0u5ZnVSkw8TFTsVJ4El4N9yVj+Vx6o3uNIB5lHIs9/U8ZVrEXVU0NbzNv7QVic0DrqvtzzC36NcFTxdbECqAxVUdQRfa5/xAxxxW2L+VmWujR4n9JqMpARzcW92YrF5XicwqNXppZW4v5TrNfsvhhTYhF2Hwx3ZjDJTVlAFgbDbpHuumzn8vs5RR7BYtugER7AYv0+xne6YA6D7SriGAPAgPLpb2R1pbOQZN2DxFOolRiLIbkBZ0qihVQp5AtDNKqtjxe0G1vePzjIrkthS9ojiiihFkdfmNEfX5jBBCZbwPviaAGZ/A++JoRGz4UDMzO4g+X8y5lCWCxRtdrU2PpHRmJ/Zv8AKQiM1SwhxeGxKsTemGKALfURuJyjvypYdQTf5ztfY5QVrDzYi0472hwbUMTXpvYHUWGnjST0iuKT0OWSn6yd82builzuNrHpM0Dd7HgsL7yZ35H0NvKVWG94cwpXRVW6a2bjK6eHpgG29r7WvaTV88obka1/DYAbzHYfMXX187z2pXNSx4N+m28U8b32aFmSXRezCvTqaiFb5sYFZfFaTVKzW07W8xK9o2Z0hF1yeyVapta+06t+h3BlaeIrEbOy00J6gXJ/MTk1FNTKu/iIG3nPojs5g1w+GpUkBsi9eSebwMnmkIyV1oMY2qBTf5QX2bfUrn94yzmJ9k/yg/swPA3qTEVtS9i5fRohV5kenUbmMKHmV2rEG0yNNvTZT9LTUeSDKTcy6h8JlJ+TNuBaQ2fBsUUUeEMr+9GCOr+9GiAGW8D74mhBmdwB8YmhAjJ8BBeZHeUZfzIbyjCBYpHi/wBm/wApJGYhCabgc2gkSBvYpgFrk8LU3nMP0h1DisRVxCUwlOk5w72N9TqeT951LIcIaaEb6nYu9+A3l9Jiq9PuMZi8O4DJWc10BG125iqvva8NUYV4/TmaMAvyPHnPHdenFjb7zV5r2eVye7GhvKxC3gGrkNZegPy8oycstegVgqX4Dyw6cW/nPO8j6uEdPeUyIqYe0xfFo9LTwR1OkzcCHezWTU6temuJc06RYBmXnUeB95TpInFlnsDkD4vGU7KTTosKlZ7eFVHA+pnenpgbDpPMjymhhKQp0KaovJI3Z28yesuFAfnFVXLsVa2B81a1JvlKnZw+z+sJ51hj3TEeUHdnkPd/WKyS+LB46QdD3Ei/Vbm8loUz1k1iG9IiZb9JMtje5shgp+T84dr+4YCfkzapS8GJaGxRRQyyLEHxRoM9xPvSMGJD0X8B74mhEzuWnxiaIR0eFMF5lzKEIZlzAeKzCnT94i54Fx/ODVzPrLnHVPpFyKnWU7Bgd7NYwBjc4puNAb3tiFNt/wA/ykuWYXQFYLybAceG/wDmIvM9fqujXi+Lp7p9hCnjVvZd7EjYTPdqsEalTvAoFRaZZGbwksOkKU6mh2Uui2b3VG9vpGZlTSo9MXJ95d12IIMVyqpNLmZrZkqFQOoYc8MDyrR1lOxAN+kjxGGbDuHsO7dtLWPu1I9gGFwftFb0N6KWPy9SL6dvK3SZ/HZao3A/lNPUdgLX+V4KxrE8gfP1hzkaYqolrtANKOm//U9rubBV5Lg7feThCSfSVzfvE2vZtVvMDpHqtszuNHaew+cPXw6o7aqlIBWb4l6TUUk6mc77J1KmHqq+kGm6iyqvCmdNQK6hlNwwuCJMW6Rn+RhU1teMH5047lvlKfZyh7MH1lvOqfsmi7PrakI+Z36I1v0IMlrR+kR5kTqSNpKnXaIRYt/CYGMK11IU3gsylvXZBkUdFCIVsR70jElrKS1gLyrXqMuyqSd7k8CZ6tSuzTGKrekEME4Vrk2HmZdxWcoNqfiaZaviCUUs4vqI8C3lLEVbV2PtTcAji1rfKJ/5P0jUvhaW2aDG4l7FncFm9xB0EFJQpvTqLUAYg6/F4tzK9cB7sXqAkcMA28oYLeo6Gq3iRiQEt6+cG7SXg7Fjf9JsrwtNKhuFsTqXYAXhPP8ANUo06bkFlDgME+EwRiaKaFdO91I9r6h1Hlae5hSFTDshpubb6iTqvzJjzTU6Dy4mqT34I9psMzVKgp1AFNn2Gq/nL2D7R4TElBSqe0DKdDqVY+fMzFLLqYcHuquiotm0ud6nrtIcPgKNHFUqwpuiF1GkN4Vbre/1lzllbkqsNVp/wM52Q9OqluHU6gfdNyLwNgMVtpblSVP8U02ZYVG78LqW6nVY6trg7CZbE4Xu31KdSsBqa1vF/ogb5IJzxfRecahtbaC8XTJ/7lpHPQyKsCRxeBsjWwY1O31/KTZBl4q4sAi4RGcj12H9Ympkn0E0vZvCpTAYj2lcGwPwdB/WaMT77EXL+g5hqiBGQ21U/ELfD1tD+TZqtOyvqCPurH4pl6VALVR2Bdy2gqt9AU7bwFmtcDGNTJHgtZVOwFtxIraptEvFLWjrOcVFaiSpBB4IMbkjgUhuJgMDjaoDUixcAkX33MJ4TOQjCi5NN7XW/uOPQzVGVV70YcmFz52dAU3jpm6ONqW2N/WSrjakdtGfYWxvumBTJWxTtsZHBr0h5FPYoJCpjKmxFM+NuAei+cp4yovdqTd97aV2u3rHYrwM9Y8cf/mOfvI8tqLVRwdi3jC/Cp4mFJ1TTOz1jhUvoGU6lV0qIummUOoBRvp6ypj6db2dQVKnwPa/MNVHWnUQmwFQaG/i4lepWUpUS9yo1i3pBeOZrsP8rrxEeGWqUHjJPHiW8EmrWp1k1LTILaCxSx3hbKcaDsTa/nJs5VSLg7jxcdY2sc1OxEZKm2mgY1Wu1F1BWmQVI0ALtexnuGw9Rk3qOSV+I8y7luISoX93x0zbp4v+xJ8BVWw8QPKwcOOUNy5a09SBMTl1RqYJqVCUIZSDawk1fKajnw1Kg7xQy3a4Vj/mHcS6d2w+Y2EH0Mchpo1z4HKHb6yZIlPZWPJdT4DsrrYhQ9OsoqnSVuy2f5Xk+Gw9PEoVUWIJBX8StfrLdSqoxDje1w4+X+mVM4o923eUmKFtiRt4j/Qw5xy10DV2qW16Z2rTNOo1Ntyp8LD8S+csogKnk3H84Xo4dMVSAqALVAJVx8Y/3iA6RamzI+zIbMD5xFRpjJpPplrAYKnqvUKgLuFb/wAj+UNaC5DVgEZQWpm1u7XzMq4PBg0+9qEKFGoM22gefz8oCxuY1MQ/6tTZ1olWFj7zt6/2l8afngXKV72y/mXaQ1PZ4cgXJRnDaQWG1x53gJsDpdXZaiMGDagSw1et4Rw+RrakpPBY7+W394TxGUuiHQWNgfCd1I+UOprTciU5VJMjOMFKsAxBBAIYbXI2MJYmvTqKCeV8SsDuIMqVQRcjuyFV7t4qZ4vCuEsUFzhz0207rAx5HriwsmKU1SJsDmHDU3AsdLo3u6v6XmgwePR9mGlhyL3F/nMScOi1Sulk7xW8VNrqWG4ji7Iab06gN/ZsHGm56Qpz8a0wMnxVU7R0F0FriRQTgM2vZKgK390ni8KgzdLVraOZcuHpnsU8JihcWL5IH5rpZFS+znkfCJRKmjVUgWUU1VvVukqDGlsSKZ/8aqCp5DQtndEOlgbHUouPK0y49NcjrZdy1D8Zn+0DPUJFMamHtVPy5jKGGd6hL1FUVEtp1XO49JbZw9ABRYjw1SfsfpBeBr0UNMmozkHQNC7XB9Zjzt8to14dcdDsDgqa7is9w1rhNvzhF8PrTxVgL3HBJtK1LFU1d0Wix0vyz+stYiqFveibL8LHdoyeTgG9K0+wbhsIKaa6dViaT2JZNipntCi9OoAKyaSdaix9z7SxgsapNVBQttq8TE3IP+ZDj6xC0ancJ7zIbXBCxMu1Q6ktfYcbCKVYNUJ1DVZVgCjhKQ7+mHqLcCoLrwf9MPYfFkgeyUeGwuSYIqV6i4gA0qZDqU2Fv6xuVU5E4mk2hYjCoXpOazAuir7h3YbecJV8vWpTt3oN1tup5gvEYsCkjGhulRkIDnaF8Li6bU7904tyNfEmF1ovKvPTPYGlXpl1A1hDquh1al67SHNcO1Suj+IJo1u+nfuR/XpCdN6f6ydLlCyOAH4P1lnElzTQB0e7kEawbrB50q0y3MudmbrZs2JJQWSlTOlEHW3U+cWDqLTrU+N303t6/wCYZwGCpoSO4W1+SDu0lxtBkIKUE2YEHu7x1XqehMY067RRbGhaig8Asu4tv/omgOJVlv6X232gvOaba6ZemrIX2Gm3I9JeWhTanbQ6XX8LdfrKxZXppl5sUtp6IcNQp1F0m1rtTb/frPctwCAFbAaSVIt+IQfToujVBSbWbq+l/CwB/wBEmq4utTqsGRwrhXBAuL9ZUZJ5dkvHXH9WQY6hUpV6b02IUsLjlbTzGGoKdUMEbQwdQUtwbH85ZxeKDaSTbTvcSxm2KQLU3vrS4BHN7S7iXWyRVKdNEGBrCpT0g6SfwN0PoZdr5nUUqgFyRb/kJSpUglJXNvCdVvST4J1qVSxFxYFD+91/pNWGuDS/pzvlR+VNrrRaGNxHwfzih0kBb2FrRTX+T/Bzfwv/ANGZ7lXxjn3HXr0cADmSZhjmplg4IIOrfgiwiinJxt8T0jSq1shYlGqU092qiOT8IPlKODywKb+EBHYjryAYooWk12Cm5p6CzYYd45vs4DAD6QriMKpQk3uRfnrFFNGOVxMee65LsG4XDotQXHvqw59J7isMhojb3KgPPpFFFOVyNH5K17/C9Rprc7Dp9pUzSgquj6QLMN4oo6kuBnmnzZ5icKhp1ltw2sW+f+ZayugpUjfcecUUXilBZbrj6CsxwALKRa6ORuOh2lJ8uuEHiADEmx9IooFSuRpx2+BO1CsrKVqOAACBcx2b4ao1MHvHufInmKKXxWmDNPkihmlCotOhUV3DAKrNv0NoYwdSsFAL3t8Y6fWKKDErbDy09A3EVLVSKlMAOrLrpjqN+I7E1UPculbTdSlnuuq0UUzNLkaE/wBEQY+jTdbvrpsR7yC4P0g3OgQmGamz1AUs4K72XrFFC5PkgNfoEMS5q0dAcLoVXf4io5EtZZXTXRNwFI0KvXTzcxRR6p80ZqlcGHsfmNNKZIYHaKKKdGfDiW9M/9k=' }} style={styles.imageS} />
      <Text style={styles.name}>Lay</Text>
      <Text style={styles.bio}>im megha . i try to develp mobile applications..these food odering sysytem app..i try to add more products in coming period</Text>
      
    </View>
  );
}

//Token Tab screen function

function SearchScreen(){
  const [cartItems, setCartItems] = useState([
    { id: 1, name: 'Strawberry chunk', price: 10, quantity: 2 },
    { id: 2, name: 'choco laying', price: 20, quantity: 1 },
    { id: 3, name: 'chees mix', price: 50, quantity: 3 },
  ]);

  // Calculate cart total
  const cartTotal = cartItems.reduce(
    (total, item) => total + item.price * item.quantity,
    0
  );

  // Remove item from cart
  const removeItem = (id) => {
    setCartItems(cartItems.filter((item) => item.id !== id));
  };

  return (
    <View style={styles.containeer}>
      <Text style={styles.title}>Cart</Text>
      {cartItems.length > 0 ? (
        <FlatList
          data={cartItems}
          renderItem={({ item }) => (
            <View style={styles.itemContainer}>
              <View style={styles.itemInfo}>
                <Text style={styles.itemName}>{item.name}</Text>
                <Text style={styles.itemPrice}>${item.price}</Text>
              </View>
              <View style={styles.itemQuantity}>
                <Text>{item.quantity}</Text>
                <TouchableOpacity onPress={() => removeItem(item.id)}>
                  <Text style={styles.removeButton}>X</Text>
                </TouchableOpacity>
              </View>
            </View>
          )}
          keyExtractor={(item) => item.id.toString()}
        />
      ) : (
        <Text>Your cart is empty.</Text>
      )}
      <Text style={styles.cartTotal}>Total: ${cartTotal}</Text>
    </View>
  );
};

// Code To Create Bottom Tabs

const Tab=createBottomTabNavigator();
function HomePage({ navigation, route }){
  const { itemId1 } = route.params;
  return(
  <Tab.Navigator
  screenOptions={({ route }) => ({
  tabBarIcon: ({focused,color,size}) => {
    if (route.name === 'Home') {
      return(
        <Ionicons
        name={focused ? 'home-outline' : 'home-outline'}
        size={size}
        color={color}
        />
      );
    }else if (route.name === 'Products') {
      return(
        <AntDesign name="shoppingcart" size={24} color="black" />
      );
    }else if (route.name === 'Search') {
      return(
        <AntDesign name="pluscircleo" size={24} color="black" />
        
      );
    }
    else if (route.name === 'profile') {
      return(
        <AntDesign name="user" size={24} color="black" />
      );}
  },
 })}
 tabBarOptions={{
   activeTintColor: 'Red',
   inactiveTintColor: 'black',
 }}>
<Tab.Screen
name="Home"
component={HomeStackScreen}
initialParams={{ itemId2: itemId1 }}
/>
<Tab.Screen name="Products" component={ProductScreen} />
<Tab.Screen name="Search" component={SearchScreen} />
<Tab.Screen name="profile" component={ProfileScreen} />
</Tab.Navigator>
  );
}



// function to create drawer

function CustomDrawerContent(props){
    return(
     <DrawerContentScrollView {...props}>
     <DrawerItemList {...props} />
     <DrawerItem
        label="Close Drawer"
        onPress={()=> props.navigation.closeDrawer()}
        />
        </DrawerContentScrollView>

    );
}

const Drawer = createDrawerNavigator();
function HomeScreen({ navigation, route }){
  const { itemId } = route.params;
  return(
    <Drawer.Navigator 
    useLegacyImplementation
    drawerContent={(props) => <CustomDrawerContent {...props} />}
    screenOptions={{
      headerStyle: {
      //  backgroundColor: '#130f40',
      },
     // headerTintColor: '#fff',
    }}>
    <Drawer.Screen
    name="Teast your favorit foods"
    component={HomePage}
    initialParams={{ itemId1: itemId }}
    />
    <Drawer.Screen name="Signout" component={LoginScreen} />
    </Drawer.Navigator>
    
  );
}



// Main Method

const RootStack = createStackNavigator();
const MainStack = createDrawerNavigator();

function MainStackScreen() {
  return(
    <MainStack.Navigator useLegacyImplementation
    screenOptions={{
      headerStyle: {
       // backgroundColor: '#130f40',
      },
     // headerTintColor: '#fff',
    }}>
      <MainStack.Screen name="Login" component={LoginScreen} />
       
    </MainStack.Navigator>
  );
}

function App() {
 return(
    <NavigationContainer>
    
    <RootStack.Navigator
    headerMode="none"
    screenOptions={{
      headerStyle: {
       // backgroundColor: '#f4511e',
      },
     // headerTintColor: '#fff',
    }}>
    
    <RootStack.Screen name="Main" component={MainStackScreen} />
    <RootStack.Screen name="Home" component={HomeScreen} />
    <RootStack.Screen name="Register" component={RegisterScreen}/>
    </RootStack.Navigator>
    </NavigationContainer>
  );
}

export default App;


// Styling

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'rgb(192,192,192)',
    padding:40,
    justifyContent: 'center',
  },
   containeer: {
    flex: 1,
    padding:20,
    },
 containerl: {
    flex: 1,
    backgroundColor: 'rgb(192,192,192)',
  
    justifyContent: 'center',
  },
  containers: {
    flex: 1,
    justifyContent:'center',
   marginLeft:10,
       marginRight:10,
    backgroundColor: 'white',
  
  },
  containerR: {
    flex: 2,
    hight:'100%',
  paddingTop:70,
  
 
    justifyContent: 'center',
  },
  inputText: {
       height:40,
       backgroundColor:'rgba(0,0,0,0.5)',
       marginBottom:10,
       fontSize:20,
       color:'#FFF',
       paddingHorizontal:10,
       
    },
    inputTextl: {
      marginTop:30,
       height:40,
       backgroundColor:'rgba(0,0,0,0.5)',
       marginBottom:30,
       marginLeft:30,
       marginRight:30,
       fontSize:30,
       color:'#FFF',
       paddingHorizontal:10,
       
    },
    buttonContainer: {
        backgroundColor:'#ffa500',
        paddingVertical:30,
        marginTop:20,
    },
    buttonContainerl: {
      marginLeft:30,
       marginRight:30,
        backgroundColor:'#454545',
        paddingVertical:10,
        marginTop:40,
    },
    buttonText: {
        textAlign:'center',
        fontSize:20,
    },
    buttonTextl: {
        textAlign:'center',
        fontSize:30,
        color:'white',
    },
    background:{

      height: '100%',
      width:'100%',
    },
  //new
  imageS: {
    width: 150,
    height: 150,
    borderRadius: 75,
    marginBottom: 16,
  },
  name: {
    fontSize: 28,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  bio: {
    fontSize: 16,
    textAlign: 'center',
    marginBottom: 16,
  },
 

  container1: {
   backgroundColor:'white',
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    height: '100%',
    
  },
  
 w: {
    width: 250,
    height: 250,
    marginBottom: 20,
     marginTop:60,
     borderRadius:'170',
    },
    
  logo: {
    width: 300,
    height: 60,
    marginTop:1,
  },
  productContainer: {

    display:'flex',
    alignItems: 'center',
    paddingVertical: 10,
    borderBottomWidth: 1,
    borderBottomColor: '#C0C0C0',
     width: 350,
    height: 330,
    marginTop:1,
     paddingLeft:'30',
  },
  productImage: {
    width: 250,
    height: 250,
    marginRight: 10,
    borderRadius:20,
  },
  productName: {
    fontSize: 20,
    fontWeight: 'bold',
    marginRight: 'auto',
    textAlign:'center',
  },

   productPrice: {
    marginTop: 5,
    fontSize: 18,
    fontWeight: 'bold',
    color: 'green',
  },
  wText: {
    color: 'black',
    fontSize: 50,
    textAlign:'center',
    marginLeft:'10',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  itemContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 10,
    padding: 10,
    backgroundColor: '#f2f2f2',
    borderRadius: 5,
  },
  itemInfo: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  itemName: {
    fontWeight: 'bold',
    marginRight: 10,
  },
  itemPrice: {
    color: '#666',
  },
  itemQuantity: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  removeButton: {
    color: 'red',
    fontWeight: 'bold',
    marginLeft: 10,
  },
  cartTotal: {
    textAlign: 'right',
    fontSize: 24,
    fontWeight: 'bold',
    marginTop: 20,
  },
});
